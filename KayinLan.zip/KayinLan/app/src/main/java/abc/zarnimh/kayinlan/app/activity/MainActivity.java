package abc.zarnimh.kayinlan.app.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;

import abc.zarnimh.kayinlan.R;

import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {



    @OnClick(R.id.btn_one) public void One(){
        startActivity(new Intent(MainActivity.this,OneActivity.class));
    }

    @OnClick(R.id.btn_two) public void Two(){
        startActivity(new Intent(MainActivity.this,TwoActivity.class));
    }

    @OnClick(R.id.btn_three) public void Three(){
        startActivity(new Intent(MainActivity.this,ThreeActivity.class));
    }

    @OnClick(R.id.btn_four) public void Four(){
        startActivity(new Intent(MainActivity.this,FourActivity.class));
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);


    }


    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus){
            YoYo.with(Techniques.DropOut)
                    .duration(3500)
                    .playOn(findViewById(R.id.btn_one));

            YoYo.with(Techniques.DropOut)
                    .duration(3000)
                    .playOn(findViewById(R.id.btn_two));

            YoYo.with(Techniques.DropOut)
                    .duration(2500)
                    .playOn(findViewById(R.id.btn_three));

            YoYo.with(Techniques.DropOut)
                    .duration(2000)
                    .playOn(findViewById(R.id.btn_four));
        }
    }
}
