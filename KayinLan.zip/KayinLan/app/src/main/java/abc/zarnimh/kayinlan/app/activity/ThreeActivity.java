package abc.zarnimh.kayinlan.app.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;

import abc.zarnimh.kayinlan.R;

public class ThreeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_three);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus){
            YoYo.with(Techniques.ZoomInLeft)
                    .duration(2000)
                    .playOn(findViewById(R.id.header));


            YoYo.with(Techniques.DropOut)
                    .duration(2000)
                    .playOn(findViewById(R.id.btn_one));

            YoYo.with(Techniques.DropOut)
                    .duration(2500)
                    .playOn(findViewById(R.id.btn_two));

            YoYo.with(Techniques.DropOut)
                    .duration(3000)
                    .playOn(findViewById(R.id.btn_three));

            YoYo.with(Techniques.DropOut)
                    .duration(3500)
                    .playOn(findViewById(R.id.btn_four));

            YoYo.with(Techniques.DropOut)
                    .duration(4000)
                    .playOn(findViewById(R.id.btn_five));

            YoYo.with(Techniques.DropOut)
                    .duration(4500)
                    .playOn(findViewById(R.id.btn_six));
        }
    }
}
