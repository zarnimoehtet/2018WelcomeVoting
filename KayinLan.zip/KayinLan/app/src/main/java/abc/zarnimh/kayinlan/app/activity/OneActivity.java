package abc.zarnimh.kayinlan.app.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;

import abc.zarnimh.kayinlan.R;


public class OneActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus){
            YoYo.with(Techniques.ZoomInLeft)
                    .duration(2000)
                    .playOn(findViewById(R.id.header));


        }
    }
}
